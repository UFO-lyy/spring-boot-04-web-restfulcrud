import json
from typing import Any, List, Optional, Union

from pydantic import Field

from app.agent.react import ReActAgent
from app.exceptions import TokenLimitExceeded
from app.logger import logger
from app.prompt.plan import NEXT_STEP_PROMPT, SYSTEM_PROMPT, SYSTEM_PROMPT_CH, NEXT_STEP_PROMPT_CH
from app.prompt.human_hf import get_system_prompt
from app.schema import  AgentState, Message, ToolCall
# from app.tool import CreateChatCompletion, Terminate, ToolCollection


TOOL_CALL_REQUIRED = "Tool calls required but none provided"


class PlanAgent(ReActAgent):
    """Base agent class for handling tool/function calls with enhanced abstraction"""

    name: str = "toolcall"
    description: str = "an agent that can execute tool calls."

    system_prompt: str = SYSTEM_PROMPT_CH
    next_step_prompt: str = NEXT_STEP_PROMPT_CH

    # available_tools: ToolCollection = ToolCollection(
    #     CreateChatCompletion(), Terminate()
    # )
    # tool_choices: TOOL_CHOICE_TYPE = ToolChoice.AUTO  # type: ignore
    # special_tool_names: List[str] = Field(default_factory=lambda: [Terminate().name])

    tool_calls: List[ToolCall] = Field(default_factory=list)
    _current_base64_image: Optional[str] = None

    max_steps: int = 30
    max_observe: Optional[Union[int, bool]] = None

    async def human_feedback(self, llm):
        prompt = input("请输入反馈建议: ")
        if prompt == "ok":
            return llm
        response = await self.llm.ask(
            messages=[],
            system_msgs=(
                [Message.system_message(get_system_prompt(llm, prompt))]
            )
        )
        logger.info(f"✨ After correction plan : {response}")
        return response


    async def think(self) -> bool:
        """Process current state and decide next actions using tools"""
        if self.next_step_prompt and self.current_step > 1:
            user_msg = Message.user_message(self.next_step_prompt)
            self.messages += [user_msg]

        try:
            # Get response with tool options
            response = await self.llm.ask(
                messages=self.messages,
                system_msgs=(
                    [Message.system_message(self.system_prompt)]
                    if self.system_prompt
                    else None
                )
            )
            logger.info(f"✨ plan thoughts: {response}")
            response = await self.human_feedback(response)

            assistant_msg = Message.assistant_message(response)
            self.memory.add_message(assistant_msg)
        except ValueError:
            raise
        except Exception as e:
            # Check if this is a RetryError containing TokenLimitExceeded
            if hasattr(e, "__cause__") and isinstance(e.__cause__, TokenLimitExceeded):
                token_limit_error = e.__cause__
                logger.error(
                    f"🚨 Token limit error (from RetryError): {token_limit_error}"
                )
                self.memory.add_message(
                    Message.assistant_message(
                        f"Maximum token limit reached, cannot continue execution: {str(token_limit_error)}"
                    )
                )
                self.state = AgentState.FINISHED
                return False
            raise

        return True

    async def act(self) -> str:
        prompt = input("Enter plan execute res: ")
        _msg = Message.user_message(
            content="任务执行结果为：{}".format(prompt)
        )
        self.memory.add_message(_msg)

        return "123"

