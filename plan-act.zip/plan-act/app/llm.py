from typing import Dict, Union, List, Optional

from app.schema import Message, ROLE_VALUES

from openai import (
    APIError,
    AsyncAzureOpenAI,
    AsyncOpenAI,
    AuthenticationError,
    OpenAIError,
    RateLimitError,
)

class LLM:
    def __init__(self):
        self.model = "gpt-4o-mini"
        self.base_url = "https://api.openai.com/v1"
        self.api_key = "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"  # Replace with your actual API key
        self.client = AsyncOpenAI(api_key=self.api_key, base_url=self.base_url)
    @staticmethod
    def format_messages(
            messages: List[Union[dict, Message]]
    ) -> List[dict]:
        formatted_messages = []

        for message in messages:
            if isinstance(message, Message):
                message = message.to_dict()

            if isinstance(message, dict):
                if "role" not in message:
                    raise ValueError("Message dict must contain 'role' field")
                formatted_messages.append(message)

        for msg in formatted_messages:
            if msg["role"] not in ROLE_VALUES:
                raise ValueError(f"Invalid role: {msg['role']}")

        return formatted_messages

    async def ask(
            self,
            messages: List[Union[dict, Message]],
            system_msgs: Optional[List[Union[dict, Message]]] = None,
            temperature: Optional[float] = None,
    ) -> str:
        if system_msgs:
            system_msgs = self.format_messages(system_msgs)
            messages = system_msgs + self.format_messages(messages)
        else:
            messages = self.format_messages(messages)

        params = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature
        }

        response = await self.client.chat.completions.create(
            **params, stream=False
        )
        if not response.choices or not response.choices[0].message.content:
            raise ValueError("Empty or invalid response from LLM")

        return response.choices[0].message.content
