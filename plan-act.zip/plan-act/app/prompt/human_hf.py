def get_system_prompt(llm_plan, human):
    system_prompt = '''你是一个有用的助手，负责根据用户的反馈，修正并优化由大模型生成的测试计划，以更好地满足基于人类反馈的需求。
大模型生成的测试计划如下:
{}

人给反馈如下:
{}

你的输出应该和大模型之前输出保持一致，首先，你应该提供规划该任务的具体思路。在那之后你有两个选择
1）制定当前的具体子测试任务，并等待子任务的具体执行结果。你的子任务应该包含在<sub_task></sub_task>的XML标记中，例如：
<sub_task>
创建一个虚拟的测试环境
</sub_task>
2）当你认为已经完成测试目标后，直接给出最终的执行报告。执行报告应该包含在 <report＞</report＞的XML标记中，例如：
<report>
测试执行结果如下XXXX
</report>
'''.format(llm_plan, human)
    return system_prompt

def get_test_judge_prompt(human):
    system_prompt = '''你是一个测试专家，负责判断用户输入的问题是否是测试相关的话题，如果是测试相关话题，回答是，否则回答否。
注意，你的回答只能是是，或则否，不要包含其他回答。
    
用户的输入如下:
{human}

'''
    return system_prompt

