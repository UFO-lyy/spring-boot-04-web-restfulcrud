import asyncio

from app.schema import GuardrailFunctionOutput, Message
from app.agent.plan import PlanAgent
from app.logger import logger
from app.prompt.human_hf import get_test_judge_prompt


async def budget_guardrail(input_data, context, llm):
    """Check if the user's travel budget is realistic."""
    get_test_judge_prompt(input_data)
    response = await llm.ask(
        messages=[],
        system_msgs=(
            [Message.system_message(get_test_judge_prompt(input_data))]
        )
    )
    not_test_prompt = False if response == "是" else True
    return GuardrailFunctionOutput(
        output_info= "122",
        tripwire_triggered= not_test_prompt
    )

async def main():
    contxt = {"2": 212}

    try:
        prompt = input("Enter your prompt: ")
        if not prompt.strip():
            logger.warning("Empty prompt provided.")
            return
        agent = PlanAgent(contxt=contxt, original_input=prompt, input_guardrails=budget_guardrail)
        logger.warning("Processing your request...")
        await agent.run(prompt)
        logger.info("Request processing completed.")
    except KeyboardInterrupt:
        logger.warning("Operation interrupted.")


if __name__ == "__main__":
    asyncio.run(main())
